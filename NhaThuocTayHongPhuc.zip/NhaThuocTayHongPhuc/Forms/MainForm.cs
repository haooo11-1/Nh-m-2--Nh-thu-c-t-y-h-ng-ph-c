using NhaThuocTayHongPhuc.Data;
using NhaThuocTayHongPhuc.Models;
using NhaThuocTayHongPhuc.Services;
using System.Drawing;

namespace NhaThuocTayHongPhuc.Forms;

public sealed class MainForm : Form
{
    private readonly DatabaseService _database = new();
    private readonly SaleService _saleService = new();
    private readonly List<DrugLot> _lots = new();
    private readonly List<CartLine> _cart = new();
    private readonly DataGridView _inventoryGrid = CreateGrid();
    private readonly DataGridView _catalogGrid = CreateGrid();
    private readonly DataGridView _warningGrid = CreateGrid();
    private readonly DataGridView _cartGrid = CreateGrid();
    private readonly TextBox _searchBox = new();
    private readonly NumericUpDown _quantityInput = new() { Minimum = 1, Maximum = 999, Value = 1, Width = 70 };
    private readonly Label _connectionStatus = new();
    private readonly Label _cartTotal = new();
    private readonly Label _alertCount = new();
    private readonly Label _stockCount = new();
    private readonly Label _todayRevenue = new();

    public MainForm()
    {
        Text = "Nhà thuốc Tây Hồng Phúc";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1100, 700);
        BackColor = Color.FromArgb(245, 247, 250);
        Font = new Font("Segoe UI", 10F);
        BuildLayout();
        LoadData();
    }

    private void BuildLayout()
    {
        var header = new Panel { Dock = DockStyle.Top, Height = 76, BackColor = Color.FromArgb(13, 92, 85) };
        header.Controls.Add(new Label { Text = "NHÀ THUỐC TÂY HỒNG PHÚC", ForeColor = Color.White, Font = new Font("Segoe UI", 20, FontStyle.Bold), AutoSize = true, Location = new Point(24, 14) });
        header.Controls.Add(new Label { Text = "Quản lý lô thuốc - bán hàng - cảnh báo hạn dùng", ForeColor = Color.FromArgb(210, 240, 232), AutoSize = true, Location = new Point(27, 49) });
        _connectionStatus.Text = "Đang kiểm tra CSDL...";
        _connectionStatus.ForeColor = Color.White;
        _connectionStatus.AutoSize = true;
        _connectionStatus.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _connectionStatus.Location = new Point(830, 28);
        header.Controls.Add(_connectionStatus);
        Controls.Add(header);

        var tabs = new TabControl { Dock = DockStyle.Fill, Padding = new Point(16, 8) };
        tabs.TabPages.Add(BuildDashboardTab());
        tabs.TabPages.Add(BuildSalesTab());
        tabs.TabPages.Add(BuildInventoryTab());
        tabs.TabPages.Add(BuildWarningsTab());
        Controls.Add(tabs);
    }

    private TabPage BuildDashboardTab()
    {
        var page = new TabPage("Tổng quan") { BackColor = Color.FromArgb(245, 247, 250), Padding = new Padding(24) };
        var title = new Label { Text = "Tổng quan nhà thuốc", Font = new Font("Segoe UI", 18, FontStyle.Bold), AutoSize = true, Location = new Point(24, 24) };
        page.Controls.Add(title);
        page.Controls.Add(CreateMetric("Lô thuốc sắp hết hạn", _alertCount, Color.FromArgb(211, 91, 66), 24, 90));
        page.Controls.Add(CreateMetric("Mặt hàng đang kinh doanh", _stockCount, Color.FromArgb(13, 92, 85), 280, 90));
        page.Controls.Add(CreateMetric("Doanh thu hôm nay", _todayRevenue, Color.FromArgb(47, 115, 170), 536, 90));
        var note = new Label { Text = "Luồng làm việc đề xuất\n1. Kiểm tra cảnh báo hạn dùng mỗi sáng\n2. Khi bán, hệ thống tự ưu tiên lô gần hết hạn\n3. Cuối ngày xem doanh thu và đối soát hóa đơn", AutoSize = true, Location = new Point(30, 240), Font = new Font("Segoe UI", 12), ForeColor = Color.FromArgb(55, 65, 81) };
        page.Controls.Add(note);
        return page;
    }

    private TabPage BuildSalesTab()
    {
        var page = new TabPage("Bán hàng") { BackColor = Color.White, Padding = new Padding(16) };
        page.Controls.Add(new Label { Text = "Tìm thuốc", AutoSize = true, Location = new Point(18, 20) });
        _searchBox.Location = new Point(18, 45); _searchBox.Width = 360; _searchBox.PlaceholderText = "Tên thuốc hoặc mã lô...";
        _searchBox.TextChanged += (_, _) => RefreshInventoryGrid(_searchBox.Text);
        page.Controls.Add(_searchBox);
        page.Controls.Add(new Label { Text = "Số lượng", AutoSize = true, Location = new Point(395, 20) });
        _quantityInput.Location = new Point(395, 43);
        page.Controls.Add(_quantityInput);
        var addButton = new Button { Text = "Thêm vào hóa đơn", Location = new Point(480, 42), Width = 150, Height = 30, BackColor = Color.FromArgb(13, 92, 85), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
        addButton.Click += (_, _) => AddSelectedToCart(); page.Controls.Add(addButton);
        var invoiceButton = new Button { Text = "Thanh toán / In hóa đơn", Location = new Point(645, 42), Width = 180, Height = 30, BackColor = Color.FromArgb(211, 91, 66), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
        invoiceButton.Click += (_, _) => Checkout(); page.Controls.Add(invoiceButton);
        _inventoryGrid.Location = new Point(18, 90); _inventoryGrid.Size = new Size(650, 480); page.Controls.Add(_inventoryGrid);
        _cartGrid.Location = new Point(690, 90); _cartGrid.Size = new Size(350, 390); page.Controls.Add(_cartGrid);
        _cartTotal.Text = "Tổng: 0 đ"; _cartTotal.Font = new Font("Segoe UI", 14, FontStyle.Bold); _cartTotal.AutoSize = true; _cartTotal.Location = new Point(690, 500); page.Controls.Add(_cartTotal);
        return page;
    }

    private TabPage BuildInventoryTab()
    {
        var page = new TabPage("Kho thuốc") { BackColor = Color.White, Padding = new Padding(18) };
        page.Controls.Add(new Label { Text = "Danh sách thuốc theo từng lô", Font = new Font("Segoe UI", 16, FontStyle.Bold), AutoSize = true, Location = new Point(18, 18) });
        var refresh = new Button { Text = "Làm mới", Location = new Point(850, 18), Width = 110 };
        refresh.Click += (_, _) => LoadData(); page.Controls.Add(refresh);
        _catalogGrid.Location = new Point(18, 65); _catalogGrid.Size = new Size(960, 500); page.Controls.Add(_catalogGrid);
        return page;
    }

    private TabPage BuildWarningsTab()
    {
        var page = new TabPage("Cảnh báo hạn dùng") { BackColor = Color.White, Padding = new Padding(18) };
        page.Controls.Add(new Label { Text = "Cần xử lý trước khi thuốc bị hủy", Font = new Font("Segoe UI", 16, FontStyle.Bold), AutoSize = true, Location = new Point(18, 18) });
        page.Controls.Add(new Label { Text = "Ngưỡng cảnh báo mặc định: 30 ngày", AutoSize = true, Location = new Point(20, 48), ForeColor = Color.DimGray });
        _warningGrid.Location = new Point(18, 80); _warningGrid.Size = new Size(960, 480); page.Controls.Add(_warningGrid);
        return page;
    }

    private static Panel CreateMetric(string title, Label value, Color color, int x, int y)
    {
        var panel = new Panel { Location = new Point(x, y), Size = new Size(230, 110), BackColor = color };
        panel.Controls.Add(new Label { Text = title, ForeColor = Color.White, AutoSize = true, Location = new Point(16, 16) });
        value.Text = "0"; value.ForeColor = Color.White; value.Font = new Font("Segoe UI", 24, FontStyle.Bold); value.AutoSize = true; value.Location = new Point(16, 45); panel.Controls.Add(value);
        return panel;
    }

    private static DataGridView CreateGrid() => new() { AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoGenerateColumns = true, BackgroundColor = Color.White, BorderStyle = BorderStyle.FixedSingle, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };

    private void LoadData()
    {
        try
        {
            _lots.Clear();
            var connected = _database.CanConnect();
            _lots.AddRange(connected ? _database.LoadDrugLots() : DemoData());
            _connectionStatus.Text = connected ? "● Đã kết nối SQL Server" : "● Chế độ demo - chưa kết nối CSDL";
            _connectionStatus.ForeColor = connected ? Color.LightGreen : Color.Khaki;
        }
        catch
        {
            _lots.Clear(); _lots.AddRange(DemoData());
            _connectionStatus.Text = "● Chế độ demo - kiểm tra SQL Server"; _connectionStatus.ForeColor = Color.Khaki;
        }
        RefreshInventoryGrid(); RefreshCatalogGrid(); RefreshWarningGrid(); UpdateDashboard();
    }

    private void RefreshInventoryGrid(string filter = "")
    {
        var grid = _inventoryGrid;
        grid.DataSource = _lots.Where(x => string.IsNullOrWhiteSpace(filter) || x.Name.Contains(filter, StringComparison.OrdinalIgnoreCase) || x.Code.Contains(filter, StringComparison.OrdinalIgnoreCase)).Select(x => new { x.Id, TenThuoc = x.Name, MaLo = x.Code, Nhom = x.Category, HanDung = x.ExpiryDate.ToString("dd/MM/yyyy"), Ton = x.Quantity, GiaBan = x.SalePrice.ToString("N0") + " đ", TrangThai = x.ExpiryStatus }).ToList();
    }

    private void RefreshCatalogGrid() => _catalogGrid.DataSource = _lots.Select(x => new { x.Id, TenThuoc = x.Name, MaLo = x.Code, Nhom = x.Category, HanDung = x.ExpiryDate.ToString("dd/MM/yyyy"), Ton = x.Quantity, GiaBan = x.SalePrice.ToString("N0") + " đ", TrangThai = x.ExpiryStatus }).ToList();

    private void RefreshWarningGrid() => _warningGrid.DataSource = _saleService.GetExpiryWarnings(_lots).Select(x => new { TenThuoc = x.Name, MaLo = x.Code, HanDung = x.ExpiryDate.ToString("dd/MM/yyyy"), ConLai = x.DaysToExpiry < 0 ? "Đã quá hạn" : x.DaysToExpiry + " ngày", Ton = x.Quantity, MucDo = x.DaysToExpiry < 0 ? "NGUY HIỂM" : "CẦN XỬ LÝ" }).ToList();

    private void AddSelectedToCart()
    {
        if (_inventoryGrid.SelectedRows.Count == 0) { MessageBox.Show("Hãy chọn một lô thuốc."); return; }
        var id = Convert.ToInt32(_inventoryGrid.SelectedRows[0].Cells["Id"].Value);
        var lot = _lots.First(x => x.Id == id);
        var quantity = (int)_quantityInput.Value;
        if (quantity > lot.Quantity) { MessageBox.Show("Số lượng vượt quá tồn kho của lô này."); return; }
        var line = _cart.FirstOrDefault(x => x.Lot.Id == lot.Id);
        if (line is null) _cart.Add(new CartLine { Lot = lot, Quantity = quantity }); else line.Quantity = Math.Min(lot.Quantity, line.Quantity + quantity);
        RefreshCart();
    }

    private void RefreshCart()
    {
        _cartGrid.DataSource = _cart.Select(x => new { TenThuoc = x.Lot.Name, MaLo = x.Lot.Code, SL = x.Quantity, DonGia = x.Lot.SalePrice.ToString("N0"), ThanhTien = x.Amount.ToString("N0") }).ToList();
        _cartTotal.Text = "Tổng: " + _cart.Sum(x => x.Amount).ToString("N0") + " đ";
    }

    private void Checkout()
    {
        if (_cart.Count == 0) { MessageBox.Show("Hóa đơn chưa có thuốc."); return; }
        try
        {
            if (_database.CanConnect()) _database.SaveSale(_cart, _cart.Sum(x => x.Amount));
            foreach (var line in _cart) line.Lot.Quantity -= line.Quantity;
            MessageBox.Show("Thanh toán thành công. Hóa đơn đã sẵn sàng để in.", "Hoàn tất", MessageBoxButtons.OK, MessageBoxIcon.Information);
            _cart.Clear(); RefreshCart(); LoadData();
        }
        catch (Exception ex) { MessageBox.Show("Không thể lưu hóa đơn: " + ex.Message); }
    }

    private void UpdateDashboard()
    {
        _alertCount.Text = _saleService.GetExpiryWarnings(_lots).Count.ToString();
        _stockCount.Text = _lots.Count(x => x.Quantity > 0).ToString();
        _todayRevenue.Text = "0 đ";
    }

    private static List<DrugLot> DemoData() => new()
    {
        new DrugLot { Id = 1, Code = "PAR-2401", Name = "Paracetamol 500mg", Category = "Thuốc không kê đơn", ExpiryDate = DateTime.Today.AddDays(18), Quantity = 24, SalePrice = 28000 },
        new DrugLot { Id = 2, Code = "PAR-2402", Name = "Paracetamol 500mg", Category = "Thuốc không kê đơn", ExpiryDate = DateTime.Today.AddMonths(10), Quantity = 60, SalePrice = 30000 },
        new DrugLot { Id = 3, Code = "AMO-2401", Name = "Amoxicillin 500mg", Category = "Thuốc kê đơn", RequiresPrescription = true, ExpiryDate = DateTime.Today.AddMonths(8), Quantity = 35, SalePrice = 85000 },
        new DrugLot { Id = 4, Code = "VIT-2403", Name = "Vitamin C 1000mg", Category = "Thực phẩm chức năng", ExpiryDate = DateTime.Today.AddDays(65), Quantity = 40, SalePrice = 120000 },
        new DrugLot { Id = 5, Code = "COU-2404", Name = "Thuốc ho thảo dược", Category = "Thuốc không kê đơn", ExpiryDate = DateTime.Today.AddDays(12), Quantity = 16, SalePrice = 65000 }
    };
}
