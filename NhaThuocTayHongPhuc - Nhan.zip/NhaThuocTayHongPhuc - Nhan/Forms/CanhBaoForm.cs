using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace NhaThuocTayHongPhuc
{
    public partial class CanhBaoForm : Form
    {
        private DataGridView dgvCanhBao;
        private Label lblTitle;
        // Thay đổi chuỗi kết nối phù hợp với cơ sở dữ liệu SQL Server của bạn
        private string connectionString = "Server=YOUR_SERVER;Database=NhaThuocTayHongPhuc;Trusted_Connection=True;";

        public CanhBaoForm()
        {
            InitializeComponentCustom();
            LoadSapHetHanData();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "Cảnh Báo Thuốc Sắp Hết Hạn";
            this.Size = new System.Drawing.Size(800, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            lblTitle = new Label()
            {
                Text = "DANH SÁCH THUỐC SẮP HẾT HẠN HOẶC ĐÃ HẾT HẠN",
                Font = new System.Drawing.Font("Arial", 13, System.Drawing.FontStyle.Bold),
                Location = new System.Drawing.Point(20, 20),
                AutoSize = true
            };

            dgvCanhBao = new DataGridView()
            {
                Location = new System.Drawing.Point(20, 60),
                Size = new System.Drawing.Size(740, 380),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };

            this.Controls.Add(lblTitle);
            this.Controls.Add(dgvCanhBao);
        }

        private void LoadSapHetHanData()
        {
            // Truy vấn lấy thuốc sắp hết hạn (trong vòng 30 ngày)
            string query = @"SELECT TenThuoc AS [Tên Thuốc], 
                                    SoLo AS [Số Lô], 
                                    SoLuong AS [Số Lượng], 
                                    NgayHetHan AS [Ngày Hết Hạn] 
                             FROM Thuoc 
                             WHERE NgayHetHan <= DATEADD(day, 30, GETDATE())
                             ORDER BY NgayHetHan ASC";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvCanhBao.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối cơ sở dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}