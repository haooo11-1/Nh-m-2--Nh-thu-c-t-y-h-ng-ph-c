using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace NhaThuocTayHongPhuc
{
    public partial class BaoCaoForm : Form
    {
        private DateTimePicker dtpTuNgay;
        private DateTimePicker dtpDenNgay;
        private Button btnLoc;
        private DataGridView dgvBaoCao;
        private Label lblDoanhThu;
        private string connectionString = "Server=YOUR_SERVER;Database=NhaThuocTayHongPhuc;Trusted_Connection=True;";

        public BaoCaoForm()
        {
            InitializeComponentCustom();
            LoadBaoCaoData(DateTime.MinValue, DateTime.MaxValue);
        }

        private void InitializeComponentCustom()
        {
            this.Text = "Báo Cáo Doanh Thu & Bán Hàng";
            this.Size = new System.Drawing.Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Bộ lọc thời gian
            Label lblTu = new Label() { Text = "Từ ngày:", Location = new System.Drawing.Point(20, 20), AutoSize = true };
            dtpTuNgay = new DateTimePicker() { Location = new System.Drawing.Point(85, 16), Format = DateTimePickerFormat.Short, Width = 120 };

            Label lblDen = new Label() { Text = "Đến ngày:", Location = new System.Drawing.Point(225, 20), AutoSize = true };
            dtpDenNgay = new DateTimePicker() { Location = new System.Drawing.Point(295, 16), Format = DateTimePickerFormat.Short, Width = 120 };

            btnLoc = new Button() { Text = "Lọc Doanh Thu", Location = new System.Drawing.Point(435, 15), Width = 110, Height = 26 };
            btnLoc.Click += BtnLoc_Click;

            // Hiển thị tổng doanh thu
            lblDoanhThu = new Label() 
            { 
                Text = "Tổng Doanh Thu: 0 VNĐ", 
                Font = new System.Drawing.Font("Arial", 11, System.Drawing.FontStyle.Bold), 
                Location = new System.Drawing.Point(565, 18), 
                AutoSize = true 
            };

            // Bảng hiển thị thông tin bán hàng
            dgvBaoCao = new DataGridView()
            {
                Location = new System.Drawing.Point(20, 60),
                Size = new System.Drawing.Size(840, 480),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };

            this.Controls.Add(lblTu);
            this.Controls.Add(dtpTuNgay);
            this.Controls.Add(lblDen);
            this.Controls.Add(dtpDenNgay);
            this.Controls.Add(btnLoc);
            this.Controls.Add(lblDoanhThu);
            this.Controls.Add(dgvBaoCao);
        }

        private void BtnLoc_Click(object sender, EventArgs e)
        {
            DateTime tuNgay = dtpTuNgay.Value.Date;
            DateTime denNgay = dtpDenNgay.Value.Date.AddDays(1).AddSeconds(-1); // Lấy hết cuối ngày
            LoadBaoCaoData(tuNgay, denNgay);
        }

        private void LoadBaoCaoData(DateTime tuNgay, DateTime denNgay)
        {
            string query = @"SELECT MaHD AS [Mã HĐ], 
                                    NgayBan AS [Ngày Bán], 
                                    MaKH AS [Mã Khách Hàng], 
                                    TongTien AS [Tổng Tiền] 
                             FROM HoaDon 
                             WHERE (@TuNgay = '0001-01-01' OR NgayBan BETWEEN @TuNgay AND @DenNgay)
                             ORDER BY NgayBan DESC";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@TuNgay", tuNgay == DateTime.MinValue ? (object)DBNull.Value : tuNgay);
                    cmd.Parameters.AddWithValue("@DenNgay", denNgay == DateTime.MaxValue ? (object)DBNull.Value : denNgay);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvBaoCao.DataSource = dt;

                    // Tính tổng doanh thu từ các dòng dữ liệu trả về
                    decimal tongDoanhThu = 0;
                    foreach (DataRow row in dt.Rows)
                    {
                        tongDoanhThu += Convert.ToDecimal(row["Tổng Tiền"]);
                    }
                    lblDoanhThu.Text = $"Tổng Doanh Thu: {tongDoanhThu:N0} VNĐ";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu báo cáo: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}