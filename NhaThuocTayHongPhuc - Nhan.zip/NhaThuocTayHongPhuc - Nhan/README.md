# Nhà thuốc Tây Hồng Phúc

Ứng dụng desktop quản lý nhà thuốc bằng C# WinForms và SQL Server. Đây là bản nền MVP, tập trung vào luồng quản lý lô thuốc, bán hàng và cảnh báo hạn dùng.

## Chức năng bản mẫu

- Dashboard doanh thu, số lô sắp hết hạn và tổng số mặt hàng.
- Tra cứu thuốc theo tên, mã lô, nhóm hàng.
- Quản lý nhiều lô của cùng một thuốc.
- Tự động ưu tiên lô có hạn dùng gần nhất (FEFO).
- Cảnh báo thuốc hết hạn hoặc còn tối đa 30 ngày.
- Lập hóa đơn bán nhiều mặt hàng cùng lúc.
- Phân quyền nghiệp vụ: Owner và Pharmacist.
- SQL transaction khi lưu hóa đơn và trừ tồn kho.

Khi chưa kết nối được SQL Server, ứng dụng tự chuyển sang dữ liệu demo để có thể xem giao diện và thử luồng bán hàng.

## Chạy bằng Visual Studio

1. Cài Visual Studio 2022 với workload **Desktop development with .NET** và SQL Server LocalDB.
2. Mở `NhaThuocTayHongPhuc.csproj`.
3. Chạy `Database/01_CreateDatabase.sql` trong SQL Server Management Studio.
4. Kiểm tra connection string trong `Data/DatabaseService.cs`.
5. Nhấn F5.

Tài khoản mẫu: `admin/admin`, `duocsi1/123456`.

## GitHub

```powershell
git init
git add .
git commit -m "Khoi tao ung dung quan ly nha thuoc"
git branch -M main
git remote add origin https://github.com/<tai-khoan>/NhaThuocTayHongPhuc.git
git push -u origin main
```
