using Microsoft.Data.SqlClient;
using NhaThuocTayHongPhuc.Models;

namespace NhaThuocTayHongPhuc.Data;

public sealed class DatabaseService
{
    private readonly string _connectionString;

    public DatabaseService(string? connectionString = null)
    {
        _connectionString = connectionString ??
            "Server=(localdb)\\MSSQLLocalDB;Database=NhaThuocTayHongPhuc;Trusted_Connection=True;TrustServerCertificate=True;";
    }

    public bool CanConnect()
    {
        try
        {
            using var connection = new SqlConnection(_connectionString);
            connection.Open();
            return true;
        }
        catch (SqlException)
        {
            return false;
        }
    }

    public List<DrugLot> LoadDrugLots()
    {
        var result = new List<DrugLot>();
        using var connection = new SqlConnection(_connectionString);
        connection.Open();
        const string sql = "SELECT Id, LotCode, DrugName, Unit, Category, RequiresPrescription, ExpiryDate, Quantity, SalePrice FROM DrugLots WHERE IsActive = 1 ORDER BY ExpiryDate";
        using var command = new SqlCommand(sql, connection);
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            result.Add(new DrugLot
            {
                Id = reader.GetInt32(0), Code = reader.GetString(1), Name = reader.GetString(2),
                Unit = reader.GetString(3), Category = reader.GetString(4), RequiresPrescription = reader.GetBoolean(5),
                ExpiryDate = reader.GetDateTime(6), Quantity = reader.GetInt32(7), SalePrice = reader.GetDecimal(8)
            });
        }
        return result;
    }

    public void SaveSale(IEnumerable<CartLine> cart, decimal total, int? customerId = null)
    {
        using var connection = new SqlConnection(_connectionString);
        connection.Open();
        using var transaction = connection.BeginTransaction();
        try
        {
            const string invoiceSql = "INSERT INTO Invoices(InvoiceNumber, CustomerId, TotalAmount) OUTPUT INSERTED.Id VALUES (@number, @customer, @total)";
            using var invoice = new SqlCommand(invoiceSql, connection, transaction);
            invoice.Parameters.AddWithValue("@number", $"HD{DateTime.Now:yyyyMMddHHmmss}");
            invoice.Parameters.AddWithValue("@customer", (object?)customerId ?? DBNull.Value);
            invoice.Parameters.AddWithValue("@total", total);
            var invoiceId = (int)invoice.ExecuteScalar()!;

            foreach (var line in cart)
            {
                using var detail = new SqlCommand("INSERT INTO InvoiceDetails(InvoiceId, DrugLotId, Quantity, UnitPrice) VALUES (@invoice, @lot, @quantity, @price); UPDATE DrugLots SET Quantity = Quantity - @quantity WHERE Id = @lot AND Quantity >= @quantity;", connection, transaction);
                detail.Parameters.AddWithValue("@invoice", invoiceId);
                detail.Parameters.AddWithValue("@lot", line.Lot.Id);
                detail.Parameters.AddWithValue("@quantity", line.Quantity);
                detail.Parameters.AddWithValue("@price", line.Lot.SalePrice);
                detail.ExecuteNonQuery();
            }
            transaction.Commit();
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }
}
