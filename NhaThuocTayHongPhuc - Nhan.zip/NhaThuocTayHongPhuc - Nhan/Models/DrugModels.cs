namespace NhaThuocTayHongPhuc.Models;

public enum UserRole { Owner, Pharmacist }

public sealed class DrugLot
{
    public int Id { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Unit { get; set; } = "Hộp";
    public string Category { get; set; } = "Thuốc không kê đơn";
    public bool RequiresPrescription { get; set; }
    public DateTime ExpiryDate { get; set; }
    public int Quantity { get; set; }
    public decimal SalePrice { get; set; }
    public int DaysToExpiry => (ExpiryDate.Date - DateTime.Today).Days;
    public string ExpiryStatus => DaysToExpiry < 0 ? "Đã hết hạn" : DaysToExpiry <= 30 ? "Sắp hết hạn" : "Còn hạn";
}

public sealed class CartLine
{
    public DrugLot Lot { get; init; } = new();
    public int Quantity { get; set; }
    public decimal Amount => Quantity * Lot.SalePrice;
}
