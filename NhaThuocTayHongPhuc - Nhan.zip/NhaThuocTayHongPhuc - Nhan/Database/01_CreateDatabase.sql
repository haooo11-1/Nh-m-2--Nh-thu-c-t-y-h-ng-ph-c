CREATE DATABASE NhaThuocTayHongPhuc;
GO
USE NhaThuocTayHongPhuc;
GO

CREATE TABLE Users (
    Id INT IDENTITY PRIMARY KEY,
    FullName NVARCHAR(120) NOT NULL,
    Username VARCHAR(50) NOT NULL UNIQUE,
    PasswordHash VARCHAR(200) NOT NULL,
    Role VARCHAR(20) NOT NULL CHECK (Role IN ('Owner', 'Pharmacist')),
    IsActive BIT NOT NULL DEFAULT 1
);
CREATE TABLE DrugLots (
    Id INT IDENTITY PRIMARY KEY,
    LotCode VARCHAR(50) NOT NULL,
    DrugName NVARCHAR(200) NOT NULL,
    Unit NVARCHAR(30) NOT NULL,
    Category NVARCHAR(100) NOT NULL,
    RequiresPrescription BIT NOT NULL DEFAULT 0,
    ExpiryDate DATE NOT NULL,
    Quantity INT NOT NULL CHECK (Quantity >= 0),
    SalePrice DECIMAL(18,2) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
CREATE TABLE Invoices (
    Id INT IDENTITY PRIMARY KEY,
    InvoiceNumber VARCHAR(30) NOT NULL UNIQUE,
    CustomerId INT NULL,
    TotalAmount DECIMAL(18,2) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
CREATE TABLE InvoiceDetails (
    Id INT IDENTITY PRIMARY KEY,
    InvoiceId INT NOT NULL REFERENCES Invoices(Id),
    DrugLotId INT NOT NULL REFERENCES DrugLots(Id),
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL
);
GO
INSERT INTO Users(FullName, Username, PasswordHash, Role) VALUES
(N'Chủ nhà thuốc', 'admin', 'admin', 'Owner'),
(N'Dược sĩ 1', 'duocsi1', '123456', 'Pharmacist'),
(N'Dược sĩ 2', 'duocsi2', '123456', 'Pharmacist');
INSERT INTO DrugLots(LotCode, DrugName, Unit, Category, RequiresPrescription, ExpiryDate, Quantity, SalePrice) VALUES
('PAR-2401', N'Paracetamol 500mg', N'Hộp', N'Thuốc không kê đơn', 0, DATEADD(DAY, 18, GETDATE()), 24, 28000),
('PAR-2402', N'Paracetamol 500mg', N'Hộp', N'Thuốc không kê đơn', 0, DATEADD(MONTH, 10, GETDATE()), 60, 30000),
('AMO-2401', N'Amoxicillin 500mg', N'Hộp', N'Thuốc kê đơn', 1, DATEADD(MONTH, 8, GETDATE()), 35, 85000),
('VIT-2403', N'Vitamin C 1000mg', N'Ống', N'Thực phẩm chức năng', 0, DATEADD(DAY, 65, GETDATE()), 40, 120000),
('COU-2404', N'Thuốc ho thảo dược', N'Chai', N'Thuốc không kê đơn', 0, DATEADD(DAY, 12, GETDATE()), 16, 65000);
GO
