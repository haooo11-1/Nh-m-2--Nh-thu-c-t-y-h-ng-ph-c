using NhaThuocTayHongPhuc.Models;

namespace NhaThuocTayHongPhuc.Services;

public sealed class SaleService
{
    public IReadOnlyList<DrugLot> SelectLotsForSale(IEnumerable<DrugLot> lots, string drugName, int quantity)
    {
        var available = lots.Where(l => l.Name.Equals(drugName, StringComparison.OrdinalIgnoreCase) && l.Quantity > 0)
            .OrderBy(l => l.ExpiryDate).ToList();
        var selected = new List<DrugLot>();
        var remaining = quantity;
        foreach (var lot in available)
        {
            if (remaining <= 0) break;
            selected.Add(lot);
            remaining -= Math.Min(remaining, lot.Quantity);
        }
        return remaining > 0 ? Array.Empty<DrugLot>() : selected;
    }

    public List<DrugLot> GetExpiryWarnings(IEnumerable<DrugLot> lots, int warningDays = 30) =>
        lots.Where(l => l.Quantity > 0 && l.DaysToExpiry <= warningDays).OrderBy(l => l.ExpiryDate).ToList();
}
