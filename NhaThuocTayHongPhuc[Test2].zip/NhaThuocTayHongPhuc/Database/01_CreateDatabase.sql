CREATE DATABASE NhaThuocTayHongPhuc;
GO
USE NhaThuocTayHongPhuc;
GO

CREATE TABLE NguoiDung (
    ID INT IDENTITY PRIMARY KEY,
    HoTen NVARCHAR(120) NOT NULL,
    Username VARCHAR(50) NOT NULL UNIQUE,
    PasswordHash VARCHAR(200) NOT NULL,
    Role VARCHAR(20) NOT NULL CHECK (Role IN ('Chu Nha Thuoc', 'Duoc Si')),
    HoatDong BIT NOT NULL DEFAULT 1
);
CREATE TABLE Thuoc (
    ID INT IDENTITY PRIMARY KEY,
    SoCode VARCHAR(50) NOT NULL,
    TenThuoc NVARCHAR(200) NOT NULL,
    DonVi NVARCHAR(30) NOT NULL,
    TheLoai NVARCHAR(100) NOT NULL,
    CanDonThuoc BIT NOT NULL DEFAULT 0,
    HangSuDung DATE NOT NULL,
    SoLuong INT NOT NULL CHECK (SoLuong >= 0),
    GiaTien DECIMAL(18,2) NOT NULL,
    HoatDong BIT NOT NULL DEFAULT 1,
    ThoiGianTao DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
CREATE TABLE HoaDon (
    Id INT IDENTITY PRIMARY KEY,
    SoHoaDon VARCHAR(30) NOT NULL UNIQUE,
    IDKhachHang INT NULL,
    TongSoTien DECIMAL(18,2) NOT NULL,
    ThoiGianTao DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
CREATE TABLE ChiTietHoaDon (
    Id INT IDENTITY PRIMARY KEY,
    IDHoaDon INT NOT NULL REFERENCES HoaDon(Id),
    IdThuoc INT NOT NULL REFERENCES Thuoc(Id),
    SoLuong INT NOT NULL,
    DonGia DECIMAL(18,2) NOT NULL
);
GO
INSERT INTO NguoiDung(HoTen, Username, PasswordHash, Role) VALUES
(N'Chu nha thuoc', 'Quan tri vien', 'Quan tri vien', 'Chu nha thuoc'),
(N'Duoc si 1', 'duocsi1', '123456', 'Duoc Si'),
(N'Duoc si 2', 'duocsi2', '123456', 'Duoc Si');
INSERT INTO Thuoc(SoCode, TenThuoc, DonVi, TheLoai, CanDonThuoc, HangSuDung, SoLuong, GiaTien) VALUES
('PAR-2401', N'Paracetamol 500mg', N'Hộp', N'Thuoc khong ke don', 0, DATEADD(DAY, 18, GETDATE()), 24, 28000),
('PAR-2402', N'Paracetamol 500mg', N'Hộp', N'Thuoc khong ke don', 0, DATEADD(MONTH, 10, GETDATE()), 60, 30000),
('AMO-2401', N'Amoxicillin 500mg', N'Hộp', N'Thuoc ke don', 1, DATEADD(MONTH, 8, GETDATE()), 35, 85000),
('VIT-2403', N'Vitamin C 1000mg', N'Ống', N'Thuc pham chuc nang', 0, DATEADD(DAY, 65, GETDATE()), 40, 120000),
('COU-2404', N'Thuốc ho thảo dược', N'Chai', N'Thuoc khong ke don', 0, DATEADD(DAY, 12, GETDATE()), 16, 65000);
GO
